'use client';

import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { useState } from 'react';

const testimonials = [
  {
    quote:
      "Pedro is one of the most talented engineers I've worked with. His attention to detail and ability to translate complex requirements into elegant solutions is remarkable.",
    author: 'Sarah Chen',
    role: 'CTO, Tech Innovators Inc.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop'
  },
  {
    quote:
      'Working with Pedro was a game-changer for our project. He delivered ahead of schedule with code quality that set a new standard for our team.',
    author: 'Michael Rodriguez',
    role: 'Product Manager, Digital Solutions',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop'
  },
  {
    quote:
      "Pedro's expertise in React and TypeScript helped us rebuild our entire frontend in record time. His architectural decisions continue to pay dividends.",
    author: 'Emily Watson',
    role: 'Engineering Lead, StartUp Labs',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop'
  },
  {
    quote:
      "Not only is Pedro technically brilliant, but he's also a fantastic communicator and team player. He elevated everyone around him.",
    author: 'David Kim',
    role: 'CEO, Innovation Hub',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'
  }
];

export function PortfolioTestimonials() {
  const [activeIndex, setActiveIndex] = useState(0);

  function next() {
    setActiveIndex(current => (current + 1) % testimonials.length);
  }

  function previous() {
    setActiveIndex(current => (current - 1 + testimonials.length) % testimonials.length);
  }

  const active = testimonials[activeIndex];

  return (
    <section id="testimonials" className="relative overflow-hidden py-32">
      <div className="absolute left-1/2 top-1/2 h-[800px] w-[800px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/5 blur-3xl" />

      <div className="container relative z-10 mx-auto px-6">
        <div className="mx-auto mb-16 max-w-3xl text-center">
          <span className="animate-fade-in text-sm font-medium uppercase tracking-wider text-secondary-foreground">
            What People Say
          </span>
          <h2 className="animation-delay-100 animate-fade-in mb-6 mt-4 text-4xl font-bold text-secondary-foreground md:text-5xl">
            Kind words from
            <span className="font-serif font-normal italic text-white"> amazing people.</span>
          </h2>
        </div>

        <div className="mx-auto max-w-4xl">
          <div className="relative">
            <div className="glass glow-border animation-delay-200 animate-fade-in rounded-3xl p-8 md:p-12">
              <div className="absolute -top-4 left-8 flex h-12 w-12 items-center justify-center rounded-full bg-primary">
                <Quote className="h-6 w-6 text-primary-foreground" />
              </div>

              <blockquote className="mb-8 pt-4 text-xl font-medium leading-relaxed md:text-2xl">
                &quot;{active.quote}&quot;
              </blockquote>

              <div className="flex items-center gap-4">
                <img
                  src={active.avatar}
                  alt={active.author}
                  className="h-14 w-14 rounded-full object-cover ring-2 ring-primary/20"
                />
                <div>
                  <div className="font-semibold">{active.author}</div>
                  <div className="text-sm text-muted-foreground">{active.role}</div>
                </div>
              </div>
            </div>

            <div className="mt-8 flex items-center justify-center gap-4">
              <button
                type="button"
                aria-label="Previous testimonial"
                className="glass rounded-full p-3 transition-all hover:bg-primary/10 hover:text-primary"
                onClick={previous}>
                <ChevronLeft />
              </button>

              <div className="flex gap-2">
                {testimonials.map((testimonial, index) => (
                  <button
                    key={testimonial.author}
                    type="button"
                    aria-label={`Show testimonial ${index + 1}`}
                    onClick={() => setActiveIndex(index)}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      index === activeIndex
                        ? 'w-8 bg-primary'
                        : 'w-2 bg-muted-foreground/30 hover:bg-muted-foreground/50'
                    }`}
                  />
                ))}
              </div>

              <button
                type="button"
                aria-label="Next testimonial"
                onClick={next}
                className="glass rounded-full p-3 transition-all hover:bg-primary/10 hover:text-primary">
                <ChevronRight />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
