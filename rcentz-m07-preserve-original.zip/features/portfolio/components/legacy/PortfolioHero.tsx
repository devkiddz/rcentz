import {
  ArrowRight,
  ChevronDown,
  Download,
  Github,
  Linkedin,
  Twitter
} from 'lucide-react';

import { PortfolioAnimatedBorderButton } from './PortfolioAnimatedBorderButton';
import { PortfolioButton } from './PortfolioButton';

const skills = [
  'React',
  'Next.js',
  'TypeScript',
  'Node.js',
  'GraphQL',
  'PostgreSQL',
  'MongoDB',
  'Redis',
  'Docker',
  'AWS',
  'Vercel',
  'Tailwind CSS',
  'Prisma',
  'Jest',
  'Cypress',
  'Figma',
  'Git',
  'GitHub Actions'
];

const socials = [
  { icon: Github, href: '#', label: 'GitHub' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Twitter, href: '#', label: 'Twitter' }
];

const dots = Array.from({ length: 30 }, (_, index) => ({
  left: `${(index * 37 + 11) % 100}%`,
  top: `${(index * 53 + 7) % 100}%`,
  duration: 15 + ((index * 7) % 20),
  delay: (index * 0.37) % 5
}));

export function PortfolioHero() {
  return (
    <section className="relative flex min-h-screen items-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://portfolio-ui-system-v0-1.vercel.app/hero-bg.jpg"
          alt=""
          className="h-full w-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-linear-to-b from-background/20 via-background/80 to-background" />
      </div>

      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {dots.map((dot, index) => (
          <div
            key={index}
            className="absolute h-1.5 w-1.5 rounded-full bg-primary opacity-60"
            style={{
              left: dot.left,
              top: dot.top,
              animation: `portfolio-slow-drift ${dot.duration}s ease-in-out infinite`,
              animationDelay: `${dot.delay}s`
            }}
          />
        ))}
      </div>

      <div className="container relative z-10 mx-auto px-6 pb-20 pt-32">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="space-y-8">
            <div className="animate-fade-in">
              <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm text-primary">
                <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
                Software Engineer • React Specialist
              </span>
            </div>

            <div className="space-y-4">
              <h1 className="animation-delay-100 animate-fade-in text-5xl font-bold leading-tight md:text-6xl lg:text-7xl">
                Crafting <span className="glow-text text-primary">digital</span>
                <br />
                experiences with
                <br />
                <span className="font-serif font-normal italic text-white">precision.</span>
              </h1>

              <p className="animation-delay-200 animate-fade-in max-w-lg text-lg text-muted-foreground">
                Hi, I&apos;m Dennis Jones — a software engineer specializing in React, Next.js, and TypeScript. I
                build scalable, performant web applications that users love.
              </p>
            </div>

            <div className="animation-delay-300 animate-fade-in flex flex-wrap gap-4">
              <PortfolioButton size="lg">
                Contact Me <ArrowRight className="h-5 w-5" />
              </PortfolioButton>

              <PortfolioAnimatedBorderButton className="animation-delay-400 animate-fade-in transition-all hover:text-primary">
                <Download className="h-5 w-5 text-primary" />
                Download CV
              </PortfolioAnimatedBorderButton>
            </div>

            <div className="animation-delay-400 animate-fade-in flex items-center gap-4">
              <span className="text-sm text-muted-foreground">Follow me:</span>

              {socials.map(social => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="glass rounded-full p-2 transition-all duration-300 hover:bg-primary/10 hover:text-primary">
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          <div className="animation-delay-300 animate-fade-in relative">
            <div className="relative mx-auto max-w-md">
              <div className="absolute inset-0 animate-pulse rounded-3xl bg-gradient-to-br from-primary/30 via-transparent to-primary/10 blur-2xl" />

              <div className="glass glow-border relative rounded-3xl p-2">
                <img
                  src="https://portfolio-ui-system-v0-1.vercel.app/profile-photo.jpg"
                  alt="Portfolio profile"
                  className="aspect-[4/5] w-full rounded-2xl object-cover"
                />

                <div className="glass animate-float absolute -bottom-4 -right-4 rounded-xl px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="h-3 w-3 animate-pulse rounded-full bg-green-500" />
                    <span className="text-sm font-medium">Available for work</span>
                  </div>
                </div>

                <div className="glass animation-delay-500 animate-float absolute -left-4 -top-4 rounded-xl px-4 py-3">
                  <div className="text-2xl font-bold text-primary">5+</div>
                  <div className="text-xs text-muted-foreground">Years Exp.</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="animation-delay-600 animate-fade-in mt-20">
          <p className="mb-6 text-center text-sm text-muted-foreground">Technologies I work with</p>

          <div className="relative overflow-hidden">
            <div className="absolute bottom-0 left-0 top-0 z-10 w-32 bg-gradient-to-r from-background to-transparent" />
            <div className="absolute bottom-0 right-0 top-0 z-10 w-32 bg-gradient-to-l from-background to-transparent" />

            <div className="animate-marquee flex">
              {[...skills, ...skills].map((skill, index) => (
                <div key={`${skill}-${index}`} className="flex-shrink-0 px-8 py-4">
                  <span className="text-xl font-semibold text-muted-foreground/50 transition-colors hover:text-muted-foreground">
                    {skill}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="animation-delay-800 animate-fade-in absolute bottom-8 left-1/2 -translate-x-1/2">
        <a
          href="#about"
          className="group flex flex-col items-center gap-2 text-muted-foreground transition-colors hover:text-primary">
          <span className="text-xs uppercase tracking-wider">Scroll</span>
          <ChevronDown className="h-6 w-6 animate-bounce" />
        </a>
      </div>
    </section>
  );
}
