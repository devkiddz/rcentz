const experiences = [
  {
    period: '2022 — Present',
    role: 'Senior Frontend Engineer',
    company: 'Tech Innovators Inc.',
    description:
      'Leading frontend architecture for a suite of fintech products. Implemented micro-frontend architecture, reduced bundle size by 40%, and mentored a team of 5 developers.',
    technologies: ['React', 'TypeScript', 'Next.js', 'GraphQL'],
    current: true
  },
  {
    period: '2020 — 2022',
    role: 'Frontend Engineer',
    company: 'Digital Solutions Co.',
    description:
      'Built and maintained multiple React applications for enterprise clients. Introduced automated testing practices that improved code coverage to 85%.',
    technologies: ['React', 'Redux', 'Jest', 'Cypress'],
    current: false
  },
  {
    period: '2019 — 2020',
    role: 'Junior Developer',
    company: 'StartUp Labs',
    description:
      'Contributed to the development of a SaaS platform from MVP to production. Collaborated with designers to implement pixel-perfect UI components.',
    technologies: ['React', 'Node.js', 'MongoDB', 'AWS'],
    current: false
  },
  {
    period: '2018 — 2019',
    role: 'Freelance Developer',
    company: 'Self-Employed',
    description:
      'Delivered custom web solutions for small businesses and startups. Built 15+ websites and applications, handling everything from design to deployment.',
    technologies: ['JavaScript', 'PHP', 'WordPress', 'MySQL'],
    current: false
  }
];

export function PortfolioExperience() {
  return (
    <section id="experience" className="relative overflow-hidden py-32">
      <div className="absolute left-1/4 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-primary/5 blur-3xl" />

      <div className="container relative z-10 mx-auto px-6">
        <div className="mb-16 max-w-3xl">
          <span className="animate-fade-in text-sm font-medium uppercase tracking-wider text-secondary-foreground">
            Career Journey
          </span>
          <h2 className="animation-delay-100 animate-fade-in mb-6 mt-4 text-4xl font-bold text-secondary-foreground md:text-5xl">
            Experience that
            <span className="font-serif font-normal italic text-white"> speaks volumes.</span>
          </h2>
          <p className="animation-delay-200 animate-fade-in text-muted-foreground">
            A timeline of my professional growth, from curious beginner to senior engineer leading teams and
            building products at scale.
          </p>
        </div>

        <div className="relative">
          <div className="timeline-glow absolute bottom-0 left-0 top-0 w-[2px] bg-gradient-to-b from-primary/70 via-primary/30 to-transparent md:left-1/2 md:-translate-x-1/2" />

          <div className="space-y-12">
            {experiences.map((experience, index) => (
              <div
                key={`${experience.period}-${experience.role}`}
                className="animate-fade-in relative grid gap-8 md:grid-cols-2"
                style={{ animationDelay: `${(index + 1) * 150}ms` }}>
                <div className="absolute left-0 top-0 z-10 h-3 w-3 -translate-x-1/2 rounded-full bg-primary ring-4 ring-background md:left-1/2">
                  {experience.current ? (
                    <span className="absolute inset-0 animate-ping rounded-full bg-primary opacity-75" />
                  ) : null}
                </div>

                <div
                  className={`pl-8 md:pl-0 ${
                    index % 2 === 0 ? 'md:pr-16 md:text-right' : 'md:col-start-2 md:pl-16'
                  }`}>
                  <div className="glass rounded-2xl border border-primary/30 p-6 transition-all duration-500 hover:border-primary/50">
                    <span className="text-sm font-medium text-primary">{experience.period}</span>
                    <h3 className="mt-2 text-xl font-semibold">{experience.role}</h3>
                    <p className="text-muted-foreground">{experience.company}</p>
                    <p className="mt-4 text-sm text-muted-foreground">{experience.description}</p>
                    <div className={`mt-4 flex flex-wrap gap-2 ${index % 2 === 0 ? 'md:justify-end' : ''}`}>
                      {experience.technologies.map(technology => (
                        <span key={technology} className="rounded-full bg-surface px-3 py-1 text-xs text-muted-foreground">
                          {technology}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
