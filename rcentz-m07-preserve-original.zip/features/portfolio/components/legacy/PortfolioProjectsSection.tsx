import { ExternalLink, Github } from 'lucide-react';

import { PortfolioAnimatedBorderButton } from './PortfolioAnimatedBorderButton';

const projects = [
  {
    title: 'Fintech Dashboard',
    description:
      'A comprehensive financial analytics platform with real-time data visualization, portfolio management, and AI-powered insights.',
    image: 'https://portfolio-ui-system-v0-1.vercel.app/projects/project1.png',
    tags: ['React', 'Typescript', 'NodeJS'],
    link: '#',
    github: '#'
  },
  {
    title: 'E-Commerce Platform',
    description:
      'A full-featured e-commerce solution with inventory management, payment processing, and analytics dashboard.',
    image: 'https://portfolio-ui-system-v0-1.vercel.app/projects/project2.png',
    tags: ['Next.js', 'Stripe', 'PostgreSQL', 'Tailwind'],
    link: '#',
    github: '#'
  },
  {
    title: 'AI Writing Assistant',
    description: 'An intelligent writing tool powered by GPT-4, helping users create better content faster.',
    image: 'https://portfolio-ui-system-v0-1.vercel.app/projects/project3.png',
    tags: ['React', 'OpenAI', 'Python', 'FastAPI'],
    link: '#',
    github: '#'
  },
  {
    title: 'Project Management Tool',
    description:
      'A collaborative workspace for teams with real-time updates, task tracking, and integrations.',
    image: 'https://portfolio-ui-system-v0-1.vercel.app/projects/project4.png',
    tags: ['Next.js', 'Socket.io', 'MongoDB', 'Redis'],
    link: '#',
    github: '#'
  }
];

export function PortfolioProjectsSection() {
  return (
    <section id="projects" className="relative overflow-hidden py-32">
      <div className="absolute right-0 top-1/4 h-96 w-96 rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute bottom-1/4 left-0 h-64 w-64 rounded-full bg-highlight/5 blur-3xl" />

      <div className="container relative z-10 mx-auto px-6">
        <div className="mx-auto mb-16 max-w-3xl text-center">
          <span className="animate-fade-in text-sm font-medium uppercase tracking-wider text-secondary-foreground">
            Featured Work
          </span>
          <h2 className="animation-delay-100 animate-fade-in mb-6 mt-4 text-4xl font-bold text-secondary-foreground md:text-5xl">
            Projects that
            <span className="font-serif font-normal italic text-white"> make an impact.</span>
          </h2>
          <p className="animation-delay-200 animate-fade-in text-muted-foreground">
            A selection of my recent work, from complex web applications to innovative tools that solve real-world
            problems.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          {projects.map((project, index) => (
            <div
              key={project.title}
              className="glass group animate-fade-in overflow-hidden rounded-2xl md:row-span-1"
              style={{ animationDelay: `${(index + 1) * 100}ms` }}>
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="h-full w-full cursor-pointer object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-linear-to-t from-card via-card/50 to-transparent opacity-60" />

                <div className="absolute inset-0 flex items-center justify-center gap-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  <a
                    href={project.link}
                    aria-label={`Open ${project.title}`}
                    className="glass rounded-full p-3 transition-all hover:bg-primary hover:text-primary-foreground">
                    <ExternalLink className="h-5 w-5" />
                  </a>
                  <a
                    href={project.github}
                    aria-label={`${project.title} GitHub`}
                    className="glass rounded-full p-3 transition-all hover:bg-primary hover:text-primary-foreground">
                    <Github className="h-5 w-5" />
                  </a>
                </div>
              </div>

              <div className="space-y-4 p-6">
                <div className="flex items-start justify-between">
                  <h3 className="cursor-pointer text-xl font-semibold transition-colors group-hover:text-primary">
                    {project.title}
                  </h3>
                  <ExternalLink className="h-5 w-5 cursor-pointer text-muted-foreground transition-all group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-primary" />
                </div>

                <p className="text-sm text-muted-foreground">{project.description}</p>

                <div className="flex flex-wrap gap-2">
                  {project.tags.map(tag => (
                    <span
                      key={tag}
                      className="cursor-progress rounded-full border border-border/50 bg-surface px-4 py-1.5 text-xs font-medium text-muted-foreground transition-all duration-300 hover:border-primary/50 hover:text-primary">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="animation-delay-500 animate-fade-in mt-12 text-center">
          <PortfolioAnimatedBorderButton>
            View All Projects
            <ExternalLink className="h-5 w-5" />
          </PortfolioAnimatedBorderButton>
        </div>
      </div>
    </section>
  );
}
