import type { PortfolioProjects } from '@/features/portfolio/server/get-portfolio-projects';

import { PortfolioAbout } from './legacy/PortfolioAbout';
import { PortfolioExperience } from './legacy/PortfolioExperience';
import { PortfolioHero } from './legacy/PortfolioHero';
import { PortfolioProjectsSection } from './legacy/PortfolioProjectsSection';
import { PortfolioTestimonials } from './legacy/PortfolioTestimonials';

type PortfolioIndexProps = {
  projects: PortfolioProjects;
};

export function PortfolioIndex({ projects }: PortfolioIndexProps) {
  return (
    <div className="portfolio-legacy" data-public-project-count={projects.length}>
      <main>
        <PortfolioHero />
        <PortfolioAbout />
        <PortfolioProjectsSection />
        <PortfolioExperience />
        <PortfolioTestimonials />
      </main>
    </div>
  );
}
