RCENTZ M07 — PRESERVATION PASS

This bundle preserves the Devkiddz-Grid portfolio design inside Rcentz.

What changed:
- Old Devkiddz-Grid Navbar removed.
- Old Devkiddz-Grid Footer removed.
- Rcentz Header/Footer remain through RcentzShell.
- Hero, About, Projects, Experience and Testimonials are preserved.
- Original prototype colors, glass surfaces, glows and animations are scoped to /portfolio.
- Current Rcentz portfolio server query is retained and still feeds PortfolioIndex, but is not used visually yet.
- Original prototype images are temporarily loaded from its existing Vercel deployment for visual fidelity.

How to apply (no PowerShell script):
1. Close or stop pnpm dev if you want.
2. Open your repo: C:\Users\DeWealth\Desktop\rcentz-systems
3. Extract THIS ZIP directly into the repo root.
4. When Windows asks whether to replace existing files, choose Replace.
5. Run:
   pnpm typecheck
   pnpm lint
   pnpm dev
6. Open http://localhost:3000/portfolio

This is intentionally a baseline. Do not judge the copy/data yet; we will refactor it brick by brick after visual parity is confirmed.
